## Page 1

Raffles M&E Services Pte Ltd
PERMIT TO WORK PTW-2026-377
Work: Install and commission Chiller unit York CH-346A
Location: Hotel plant and service areas (class 441)
Valid: 2026-05-28 to 2026-06-11
Contractor: Raffles M&E Services Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
