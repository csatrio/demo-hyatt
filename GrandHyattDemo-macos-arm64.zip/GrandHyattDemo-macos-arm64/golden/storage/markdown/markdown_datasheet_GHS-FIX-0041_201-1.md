## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Wall sconce |
| Brand | Kohler |
| Model | WS-710Pro |
| Serial | SN45785347 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
