## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Chiller unit |
| Brand | Daikin |
| Model | CH-921B |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 26 |
| Weight (kg) | 380 |
| Warranty (months) | 24 |
| Manufacturer | Daikin |
