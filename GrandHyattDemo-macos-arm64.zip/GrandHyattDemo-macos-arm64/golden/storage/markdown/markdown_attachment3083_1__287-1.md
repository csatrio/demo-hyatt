## Page 1

Telok Ayer Bath and Fittings Pte Ltd
Singapore Civil Defence Force approval SCDF/FSD/26/0977
Kitchen fire suppression approval - SCDF/FSD/26/0977
Reference: SCDF/FSD/26/0977 | Date: 2026-05-06 | Valid until: 2027-05-05
To: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, attention Director of Engineering
Copy: Telok Ayer Bath and Fittings Pte Ltd, installing contractor
Subject: Approval for kitchen fire suppression system serving the induction range line and fryer hood
Dear Sir or Madam,
We refer to your application of 2026-04-20 for a wet chemical fire suppression system over the cooking
appliances on Level 4. The design drawings and nozzle schedule have been reviewed and the installation is
approved subject to the conditions below.
Conditions
1. System to be installed by a licensed fire protection contractor and commissioned against the design.
2. Manual activation point to be mounted within 1.2 m of the exit route.
3. Nozzle coverage over the range and hood to match the approved design drawing.
4. Annual servicing certificate to be submitted to the authority on request.
This approval is valid until 2027-05-05. Any change to the layout, capacity or equipment requires a fresh
submission. Please quote the reference number in all correspondence.
Yours faithfully,
Singapore Civil Defence Force, Fire Safety Department
