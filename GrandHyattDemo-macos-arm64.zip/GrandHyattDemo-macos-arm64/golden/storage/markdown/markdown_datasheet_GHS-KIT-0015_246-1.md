## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Blast chiller |
| Brand | Hobart |
| Model | BC-501S |
| Serial | SN10465686 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
