## Page 1

RECEIPT
Item: Replacement keys
Paid: S$ 24.00 on 2026-10-05
Shop: Demo hardware and stationery
Generated demo receipt.
