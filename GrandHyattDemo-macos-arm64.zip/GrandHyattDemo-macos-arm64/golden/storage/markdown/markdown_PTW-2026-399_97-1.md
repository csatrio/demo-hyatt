## Page 1

Clarke Quay Lighting Pte Ltd
PERMIT TO WORK PTW-2026-399
Work: Install and commission LED downlight array Grohe DL-956B
Location: Hotel plant and service areas (class 421)
Valid: 2026-02-10 to 2026-02-24
Contractor: Clarke Quay Lighting Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
