## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Industrial washer extractor |
| Brand | Primus |
| Model | WE-543Pro |
| Serial | SN15367955 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
