## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED display 75 inch |
| Brand | Epson |
| Model | QD-318 |
| Serial | SN25526064 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
