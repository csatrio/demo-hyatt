# Operation and maintenance manual excerpt OMM-26-0005 - Video wall controller

Equipment: Video wall controller, model VWX-8 | Supplier: Clarke Quay Lighting Pte Ltd (Crestron)

Site: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211

Revision: 2.3 | Date: 2026-03-24

This excerpt covers the routine operation and upkeep of the video wall controller installed at the hotel. Follow the sequence below and record each action in the engineering log.

Safety

\- Power down the controller before connecting or removing video inputs.

\- Use only the supplied power supply to avoid overheating.

\- Keep rack vents clear and maintain at least 50 mm of airflow.

Start-up

1\. Power on and wait for the status LED to turn solid green.

2\. Load the saved wall layout from the configuration backup.

3\. Check each input signal on the control panel.

4\. Confirm the IP control interface responds to the building management test command.

Daily operation

\- Check the status page for any red alarm.

\- Verify the video wall shows the scheduled content.

\- Record any signal loss in the AV fault log.

Cleaning

\- Dust vent grilles with a soft brush each month.

\- Wipe the casing with a dry cloth only.

\- Do not clean electronics with liquids.

Preventive maintenance schedule

| Task | Interval | Responsible |

| Dust vents and check fans | Monthly | AV technician |

| Back up configuration | Monthly | AV integrator |

| Firmware update review | Quarterly | AV integrator |

| Full system functional test | Annually | AV integrator |

Troubleshooting

| Symptom | Likely cause | Action |

| One display blank | Output cable or panel input fault | Check output cable and panel input |

| Wall layout shifted | Configuration reset | Reload the backup configuration |

| Overheating alarm | Blocked vents | Clear vents and check fan operation |

Spare parts

\- Cooling fan module, part no. VWX-F01

\- HDMI input card, part no. VWX-C04

\- Power supply unit, part no. VWX-PS2
