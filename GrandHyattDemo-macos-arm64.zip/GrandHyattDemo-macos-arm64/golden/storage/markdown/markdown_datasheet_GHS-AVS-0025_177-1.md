## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Video wall controller |
| Brand | Crestron |
| Model | VW-318X |
| Serial | SN28063483 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
