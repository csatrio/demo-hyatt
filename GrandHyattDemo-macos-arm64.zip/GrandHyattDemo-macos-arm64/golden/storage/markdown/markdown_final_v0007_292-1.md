## Page 1

AV EQUIPMENT RENTAL AGREEMENT
Line 1: Agreement 63-4408
Line 2: Rental company Showtech AV Rentals Pte Ltd
Line 3: Banquet hall events: projectors, line-array speakers, wireless microphones and a technician
on site
Line 4: Rental period 3 days, damage deposit SGD 2,000
