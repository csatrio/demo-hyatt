## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Guest room bed set |
| Brand | King Koil |
| Model | BD-577A |
| Serial | SN36211036 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
