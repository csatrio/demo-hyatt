## Data sheet

| Parameter | Value |
| --- | --- |
| Model | TDZ-20 |
| Capacity | 30 kg dry linen per cycle |
| Dimensions | 1080 x 1250 x 1900 mm (W x D x H) |
| Weight | 310 kg |
| Electrical load | 27 kW connected |
| Voltage | 400 V, 3-phase, 50 Hz |
| Utilities | Exhaust duct 200 mm with lint filter to rooftop; ambient 20 to 30 C; no water |
| Noise | 68 dB(A) |
| Warranty | 12 months from commissioning |
