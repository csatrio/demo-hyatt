## Page 1

Clarke Quay Lighting Pte Ltd
QUOTATION Q-V-013-2201
Date: 2024-11-16
To: Grand Hyatt Singapore Demo - Purchasing
Subject: Supply and install LED downlight array
Payment terms: 50% deposit, balance on delivery
Validity: 60 days
Delivery: 6-8 weeks from order
Item Qty Unit price Amount
LED downlight array Hansgrohe DL-125X x1 SGD 3,285.36 SGD 3,285.36
Total: SGD 3,285.36
Prices exclude GST. Installation, testing and commissioning included. Warranty 24 months.
