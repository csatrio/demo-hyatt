# Technical specification SPEC-26-0004 - Pass-through dishwasher

Equipment: Pass-through dishwasher, model PTX-70

Supplier: Sentosa Display Technologies Pte Ltd (Winterhalter)

Site: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211

Date: 2026-05-02 | Document: SPEC-26-0004

1\. Scope

Installed at the Level 4 scullery pass-through with a final rinse at 85 C. This specification sets out the minimum technical requirements for supply, delivery, installation, testing and commissioning under the hotel refurbishment programme.

2\. Technical data

| Parameter | Requirement |

| Model | PTX-70 |

| Capacity | 70 racks per hour |

| Dimensions | 700 x 780 x 1980 mm (W x D x H) |

| Weight | 215 kg |

| Electrical load | 18.5 kW connected |

| Voltage | 400 V, 3-phase, 50 Hz |

| Utilities | Cold water 3/4 inch at 2 bar minimum; optional hot inlet at 60 C; drain 40 mm; detergent and rinse aid dosing points |

| Noise | 62 dB(A) |

| Warranty | 12 months from commissioning |

3\. Compliance

\- Electrical installation by a licensed electrical worker to the applicable Singapore wiring standard

\- Food-contact materials to the applicable food hygiene requirements

\- Manufacturer declaration of conformity supplied with the equipment file

4\. Acceptance tests

1\. Wash and rinse cycle timing at 70 racks per hour

2\. Final rinse temperature at 85 C plus or minus 2 C on the rack

3\. Water consumption measurement per cycle

4\. Chemical dosing check with test strips

Test results are to be recorded on the commissioning form and countersigned by the hotel engineering manager before handover.
