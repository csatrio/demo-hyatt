## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Executive desk |
| Brand | Boss Design |
| Model | XD-777A |
| Serial | SN37132528 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
