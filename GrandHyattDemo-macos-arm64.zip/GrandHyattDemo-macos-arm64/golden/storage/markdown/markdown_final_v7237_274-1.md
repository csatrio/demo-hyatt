## Page 1

Sentosa Display Technologies Pte Ltd
Permit to work PTW-26-0004 - Installation of replacement
cooling tower on plant deck
Permit to Work PTW-26-0004
Contractor: Sentosa Display Technologies Pte Ltd | Supervisor: Ng Chee Hong
Valid: 2026-03-29 07:00 to 2026-03-31 18:00 | Location: Level 5 meeting rooms
Scope
Installation of replacement cooling tower on plant deck. Work is limited to the isolated equipment and the
access route shown on the attached sketch.
Isolation
Isolate the chiller and AHU starters, close chilled water valves and recover refrigerant to a certified cylinder
before breaking any joint.
Hazards and controls
- Electrical isolation and lock-out/tag-out (LOTO)
- Manual handling of heavy components
- Slips, trips and falls in service corridors
- Refrigerant handling and pressure release
- Working at height on rooftop plant
Hot work and working at height
- Hot work: No hot work is permitted under this permit.
- Working at height: Yes. Use a certified scaffold or MEWP, with harness and tie-off points inspected before use.
Signatories
| Role | Name | Signed on |
| Requesting Engineer | Benjamin Koh | ____ |
| Contractor Supervisor | Ng Chee Hong | ____ |
| Chief Engineer (approver) | Raj Kumar | ____ |
| Maintenance witness | Noor Hidayah | ____ |
The permit is void if conditions change. Contractor must stop work and inform the duty engineer immediately.
