## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Fan coil unit |
| Brand | Daikin |
| Model | FCU-713Pro |
| Serial | SN20165570 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
