## Page 1

Kampong Contract Furniture Pte Ltd
Permit to work PTW-26-0003 - Installation of new blast chiller
in main kitchen
Permit to Work PTW-26-0003
Contractor: Kampong Contract Furniture Pte Ltd | Supervisor: Ng Chee Hong
Valid: 2026-09-16 07:00 to 2026-09-19 18:00 | Location: Basement 1 laundry
Scope
Installation of new blast chiller in main kitchen. Work is limited to the isolated equipment and the access route
shown on the attached sketch.
Isolation
Isolate electrical supply at the local DB and gas at the manual valve. Apply LOTO tags, prove dead with a
voltage tester and record the lock numbers on the permit.
Hazards and controls
- Electrical isolation and lock-out/tag-out (LOTO)
- Manual handling of heavy components
- Slips, trips and falls in service corridors
- Hot surfaces and steam from cooking equipment
- Gas supply isolation and purge check
Hot work and working at height
- Hot work: Yes. Fire watch for 60 minutes after completion, extinguisher on site.
- Working at height: Yes. Use a certified scaffold or MEWP, with harness and tie-off points inspected before use.
Signatories
| Role | Name | Signed on |
| Requesting Engineer | Noor Hidayah | ____ |
| Contractor Supervisor | Ng Chee Hong | ____ |
| Chief Engineer (approver) | Raj Kumar | ____ |
| Maintenance witness | Noor Hidayah | ____ |
The permit is void if conditions change. Contractor must stop work and inform the duty engineer immediately.
