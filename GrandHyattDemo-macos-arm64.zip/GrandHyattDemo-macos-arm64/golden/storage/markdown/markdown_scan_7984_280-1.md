## Page 1

Harbourfront Furnishings Pte Ltd
Invoice INV-26-0020 - laundry supply
Tax Invoice INV-26-0020
From: Harbourfront Furnishings Pte Ltd, 35 Jurong Port Road, Singapore 221271
Bill to: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, Accounts Payable
Invoice date: 2026-08-02 | Due date: 2026-09-01
Reference PO: PO-26-0001
This invoice relates to the second delivery against purchase order PO-26-0001. Goods were received and
checked by the hotel receiving team.
Items
| # | Description | Qty | Unit price (SGD) | Amount (SGD) |
| 1 | Flatwork ironer model FI-44 | 3 | 69,744.00 | 209,232.00 |
| 2 | Industrial washer extractor model WE-47 - supply, install and commission | 2 | 27,971.00 | 55,942.00 |
Subtotal: SGD 265,174.00
GST (9%): SGD 23,865.66
Total due: SGD 289,039.66
Payment
- Payment due by 2026-09-01, quoting INV-26-0020.
- Remittance advice should be sent to the accounts team in Finance, quoting the invoice number and the PO
reference shown above.
Notes
Quantities and serial numbers were checked against the delivery note and signed by the receiving supervisor
on arrival at the loading bay, with any shortages recorded on the goods received note before this invoice was
raised.
- Please notify us within 7 days of any discrepancy in quantities.
