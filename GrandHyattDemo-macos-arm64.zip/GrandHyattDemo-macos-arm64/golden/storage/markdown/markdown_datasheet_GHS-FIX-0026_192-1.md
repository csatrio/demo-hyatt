## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Rain shower set |
| Brand | Grohe |
| Model | RS-238 |
| Serial | SN42516404 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
