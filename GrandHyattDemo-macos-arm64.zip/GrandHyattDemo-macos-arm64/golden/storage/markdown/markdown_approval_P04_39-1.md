## Page 1

Lion City Kitchen Solutions Pte Ltd
Public Utilities Board approval PUB/WS/26/2215
Water connection and backflow prevention approval - PUB/WS/26/2215
Reference: PUB/WS/26/2215 | Date: 2026-04-14 | Valid until: 2027-04-13
To: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, attention Director of Engineering
Copy: Lion City Kitchen Solutions Pte Ltd, installing contractor
Subject: Approval of water supply connection and backflow prevention for a commercial dishwasher
Dear Sir or Madam,
This letter confirms approval of the water supply connection for the pass-through dishwasher on the Level 4
scullery. The connection has been reviewed for backflow risk and drainage, and the approval is given subject to
the conditions below.
Conditions
1. Double check valve with test point to be fitted on the dishwasher inlet.
2. Backflow prevention device to be tested annually by a registered tester.
3. Trade effluent to meet sewer use requirements; grease interceptor to be serviced quarterly.
4. Monthly water meter readings to be reported to the hotel engineering office.
This approval is valid until 2027-04-13. Any change to the layout, capacity or equipment requires a fresh
submission. Please quote the reference number in all correspondence.
Yours faithfully,
Public Utilities Board, Water Supply Department
