## Page 1

Orchard Commercial Laundry Pte Ltd
PERMIT TO WORK PTW-2026-311
Work: Install and commission Industrial washer extractor Primus WE-966
Location: Hotel plant and service areas (class 432)
Valid: 2026-09-10 to 2026-09-24
Contractor: Orchard Commercial Laundry Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
