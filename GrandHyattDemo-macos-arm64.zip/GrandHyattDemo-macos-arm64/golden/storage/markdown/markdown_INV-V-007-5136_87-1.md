## Page 1

Raffles M&E Services Pte Ltd
TAX INVOICE INV-V-007-5136
Date: 2023-06-09
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2023-1104
Terms: 50% deposit, balance on delivery
Item Qty Unit price Amount
Air handling unit Daikin AHU-226X x2 SGD 40,646.00 SGD 81,292.00
Total: SGD 81,292.00
Serial numbers: SN4661231, SN4735571
