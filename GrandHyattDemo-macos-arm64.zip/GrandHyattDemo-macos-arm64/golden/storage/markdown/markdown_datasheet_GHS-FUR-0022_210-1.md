## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Restaurant dining table |
| Brand | Boss Design |
| Model | DT-228A |
| Serial | SN32921019 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
