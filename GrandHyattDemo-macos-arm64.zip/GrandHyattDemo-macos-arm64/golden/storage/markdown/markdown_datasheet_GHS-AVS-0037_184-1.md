## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Guest room television 55 inch |
| Brand | Sony |
| Model | GT-420B |
| Serial | SN30079989 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
