## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED downlight array |
| Brand | Kohler |
| Model | DL-842 |
| Serial | SN39983236 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
