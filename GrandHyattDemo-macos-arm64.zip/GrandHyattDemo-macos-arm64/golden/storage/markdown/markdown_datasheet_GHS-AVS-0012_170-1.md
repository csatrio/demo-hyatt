## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED display 75 inch |
| Brand | Sony |
| Model | QD-981X |
| Serial | SN24843358 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
