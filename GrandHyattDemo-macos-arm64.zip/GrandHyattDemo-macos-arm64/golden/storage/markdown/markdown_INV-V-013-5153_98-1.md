## Page 1

Clarke Quay Lighting Pte Ltd
TAX INVOICE INV-V-013-5153
Date: 2026-03-08
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2026-1117
Terms: 30 days from invoice
Item Qty Unit price Amount
LED downlight array Grohe DL-956B x3 SGD 3,630.00 SGD 10,890.00
Total: SGD 10,890.00
Serial numbers: SN5186743, SN5388066, SN5754102
