## Page 1

Clarke Quay Lighting Pte Ltd
TAX INVOICE INV-V-013-5034
Date: 2024-06-29
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2024-1026
Terms: 50% deposit, balance on delivery
Item Qty Unit price Amount
Crystal chandelier Grohe CD-188Pro x3 SGD 25,068.00 SGD 75,204.00
Total: SGD 75,204.00
Serial numbers: SN1869221, SN2036428, SN2145414
