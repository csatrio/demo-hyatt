## Page 1

Clarke Quay Lighting Pte Ltd
PERMIT TO WORK PTW-2024-322
Work: Install and commission Crystal chandelier Grohe CD-188Pro
Location: Hotel plant and service areas (class 422)
Valid: 2024-06-03 to 2024-06-17
Contractor: Clarke Quay Lighting Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
