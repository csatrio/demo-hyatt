## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Lobby sofa |
| Brand | Herman Miller |
| Model | LS-277S |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 80 |
| Warranty (months) | 24 |
| Manufacturer | Herman Miller |
