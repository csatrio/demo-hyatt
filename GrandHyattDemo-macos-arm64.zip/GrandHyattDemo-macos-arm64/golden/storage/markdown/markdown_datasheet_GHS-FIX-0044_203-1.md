## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Wall sconce |
| Brand | Kohler |
| Model | WS-342Pro |
| Serial | SN46398605 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
