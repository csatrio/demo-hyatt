## Page 1

Bukit Interiors Pte Ltd
PERMIT TO WORK PTW-2024-344
Work: Install and commission Lobby sofa Herman Miller LS-277S
Location: Hotel plant and service areas (class 424)
Valid: 2024-07-19 to 2024-08-02
Contractor: Bukit Interiors Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
