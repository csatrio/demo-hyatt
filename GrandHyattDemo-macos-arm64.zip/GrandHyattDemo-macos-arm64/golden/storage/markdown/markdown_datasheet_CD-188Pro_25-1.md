## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Crystal chandelier |
| Brand | Grohe |
| Model | CD-188Pro |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 80 |
| Warranty (months) | 24 |
| Manufacturer | Grohe |
