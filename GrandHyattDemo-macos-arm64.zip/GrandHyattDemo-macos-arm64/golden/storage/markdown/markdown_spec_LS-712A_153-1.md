# Technical specification: Lobby sofa

Equipment: Lobby sofa Steelcase LS-712A.

Purchased from Harbourfront Furnishings Pte Ltd under PO-2026-1182. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Steelcase |
| --- | --- |
| Model | LS-712A |
| Quantity | 3 |
| Contract value | SGD 16,722 |
