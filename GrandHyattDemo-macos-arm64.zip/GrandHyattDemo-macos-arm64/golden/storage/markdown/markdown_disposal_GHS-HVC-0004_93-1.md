## Page 1

Tropic Air Systems Pte Ltd
Asset disposal record DSP-26-0004 - Split air conditioner
Asset disposal record DSP-26-0004
Hotel: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211
Asset tag: GHS-HV-2017-SAC-22 | Record date: 2026-05-11
This record covers the disposal of one split air conditioner from the hotel fixed asset register. The asset has
been inspected and the book value has been confirmed against the register.
Asset details
| Field | Entry |
| Asset category | hvac |
| Quantity | 1 |
| Reason for disposal | Replaced under the guest room energy upgrade |
| Condition | Operable; compressor noise above guest comfort level |
| Book value (SGD) | 380.00 |
| Disposal method | scrap |
| Recipient or buyer | Licensed refrigerant recovery contractor; recovery certificate attached |
| Net proceeds (SGD) | 0.00 |
Approvals
- Engineering Manager: approved (2026-07-09)
- Financial Controller: pending
The asset is removed from the register only after all approvals are recorded and the disposal certificate or
receipt is filed with this record.
