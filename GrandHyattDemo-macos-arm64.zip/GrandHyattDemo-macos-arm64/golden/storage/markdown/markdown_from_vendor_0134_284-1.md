# Operation and maintenance manual excerpt OMM-26-0004 - LED display 75 inch

Equipment: LED display 75 inch, model QDX-75 | Supplier: Merlion AV Integrators Pte Ltd (Samsung)

Site: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211

Revision: 2.2 | Date: 2026-02-17

This excerpt covers the routine operation and upkeep of the led display 75 inch installed at the hotel. Follow the sequence below and record each action in the engineering log.

Safety

\- Panels are heavy; use two persons and a certified wall bracket when mounting or removing.

\- Isolate power before opening the rear service cover.

\- Do not touch the screen with sharp objects.

Start-up

1\. Connect power and wait 60 seconds for the boot screen.

2\. Select the correct input on the signage controller.

3\. Set brightness to the level specified by the AV team for the foyer.

4\. Confirm network connection and firmware version.

Daily operation

\- Check for dead pixels, image sticking and colour shift during the first content cycle.

\- Confirm the schedule has loaded from the content server.

\- Log any fault codes in the AV register.

Cleaning

\- Power off and let the display cool before cleaning.

\- Wipe the screen with a dry microfibre cloth; use a small amount of screen-safe cleaner if needed.

\- Never spray liquid directly onto the panel.

Preventive maintenance schedule

| Task | Interval | Responsible |

| Clean screen and vents | Monthly | AV technician |

| Check firmware and content player health | Quarterly | AV integrator |

| Verify brightness calibration | Semi-annually | AV integrator |

| Inspect mounting brackets and cables | Annually | Engineering technician |

Troubleshooting

| Symptom | Likely cause | Action |

| No picture | Wrong input or cable fault | Select correct input; swap HDMI cable |

| Image sticking | Static content for long periods | Run pixel refresh cycle; vary content |

| Flickering at edges | Loose ribbon connection or power fault | Power cycle; call AV integrator if it persists |

Spare parts

\- Power supply board, part no. QDX-PS75

\- HDMI input board, part no. QDX-IO02

\- Remote control, part no. QDX-RC01
