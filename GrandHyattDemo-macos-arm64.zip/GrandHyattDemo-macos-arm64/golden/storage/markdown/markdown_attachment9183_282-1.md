# Technical specification SPEC-26-0007 - Tumble dryer

Equipment: Tumble dryer, model TDX-30

Supplier: Bukit Interiors Pte Ltd (Girbau)

Site: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211

Date: 2026-08-23 | Document: SPEC-26-0007

1\. Scope

Installed in pairs in the Level B2 linen room with ducted exhaust through a fire-rated damper. This specification sets out the minimum technical requirements for supply, delivery, installation, testing and commissioning under the hotel refurbishment programme.

2\. Technical data

| Parameter | Requirement |

| Model | TDX-30 |

| Capacity | 30 kg dry linen per cycle |

| Dimensions | 1080 x 1250 x 1900 mm (W x D x H) |

| Weight | 310 kg |

| Electrical load | 27 kW connected |

| Voltage | 400 V, 3-phase, 50 Hz |

| Utilities | Exhaust duct 200 mm with lint filter to rooftop; ambient 20 to 30 C; no water |

| Noise | 68 dB(A) |

| Warranty | 12 months from commissioning |

3\. Compliance

\- Electrical installation by a licensed electrical worker to the applicable Singapore wiring standard

\- Guarding of moving parts per workplace safety and health requirements

\- Manufacturer declaration of conformity supplied with the equipment file

4\. Acceptance tests

1\. Heating element load check per phase

2\. Drying time with a 15 kg cotton load to 2 percent residual moisture

3\. Lint filter and exhaust airflow measurement

4\. Door interlock and emergency stop test

Test results are to be recorded on the commissioning form and countersigned by the hotel engineering manager before handover.
