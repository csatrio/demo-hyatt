## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED display 75 inch |
| Brand | Epson |
| Model | QD-550Pro |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 26 |
| Weight (kg) | 180 |
| Warranty (months) | 24 |
| Manufacturer | Epson |
