## Page 1

PEST CONTROL SERVICE REPORT
Line 1: Report 41-2201
Line 2: SafeGuard Pest Management Pte Ltd
Line 3: Monthly inspection of kitchens, bins and loading bay: rodent bait stations checked, cockroach
gel treatment applied
Line 4: Next visit in 30 days; no live activity found in guest areas
