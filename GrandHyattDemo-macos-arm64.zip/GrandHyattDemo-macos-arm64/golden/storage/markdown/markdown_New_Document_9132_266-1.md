# Operation and maintenance manual excerpt OMM-26-0006 - Guest room television 55 inch

Equipment: Guest room television 55 inch, model GTX-55 | Supplier: Kampong Contract Furniture Pte Ltd (LG)

Site: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211

Revision: 2.1 | Date: 2026-04-04

This excerpt covers the routine operation and upkeep of the guest room television 55 inch installed at the hotel. Follow the sequence below and record each action in the engineering log.

Safety

\- Mount the television only with the approved wall bracket and do not lean on the screen.

\- Disconnect power when moving or replacing the set.

\- Do not block vents when the set is placed in a cabinet.

Start-up

1\. Turn on the set at the room controller or remote.

2\. Select hospitality mode to load the welcome screen.

3\. Check the HDMI inputs and the casting feature.

4\. Confirm room number and language settings.

Daily operation

\- Check picture and sound during room turndown.

\- Confirm there is no ghost image or static.

\- Report faulty remotes to housekeeping for replacement.

Cleaning

\- Power off the set before cleaning.

\- Clean the screen with a dry microfibre cloth.

\- Clean remote buttons with a lightly dampened cloth; no spray.

Preventive maintenance schedule

| Task | Interval | Responsible |

| Check and replace remote batteries | Quarterly | Housekeeping |

| Test inputs and hospitality mode | Quarterly | Engineering technician |

| Software update check | Semi-annually | Engineering technician |

| Inspect wall bracket and cable | Annually | Engineering technician |

Troubleshooting

| Symptom | Likely cause | Action |

| No sound | Mute or audio output setting | Check mute and audio output selection |

| Screen remains black | Power or input problem | Check power and input; power cycle the set |

| Remote not responding | Batteries flat or sensor obstructed | Replace batteries and clear the sensor window |

Spare parts

\- Remote control, part no. GTX-RC55

\- Power board, part no. GTX-PB01

\- Wall bracket kit, part no. GTX-WB02
