## Page 1

Lion City Kitchen Solutions Pte Ltd
TAX INVOICE INV-V-001-5187
Date: 2025-07-12
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2025-1143
Terms: 30 days from invoice
Item Qty Unit price Amount
Pass-through dishwasher Foster PT-195Pro x2 SGD 15,308.00 SGD 30,616.00
Total: SGD 30,616.00
Serial numbers: SN6546929, SN6864033
