## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED display 75 inch |
| Brand | Epson |
| Model | QD-826 |
| Serial | SN24193538 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
