## Page 1

Grand Hyatt Singapore Demo - Engineering
ASSET DISPOSAL FORM GHS-KIT-0032
Asset: Ice machine IM-345S
Serial: SN14294580
Reason: Replaced by Induction range 6 zone (IR-6Z900)
Date: 2026-11-15
Method: Sold to licensed recycler
