# Technical specification: Industrial washer extractor

Equipment: Industrial washer extractor Primus WE-966.

Purchased from Orchard Commercial Laundry Pte Ltd under PO-2026-1013. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Primus |
| --- | --- |
| Model | WE-966 |
| Quantity | 1 |
| Contract value | SGD 32,641 |
