## Page 1

RECEIPT
Item: Staff briefing refreshments
Paid: S$ 96.00 on 2026-10-16
Shop: Demo hardware and stationery
Generated demo receipt.
