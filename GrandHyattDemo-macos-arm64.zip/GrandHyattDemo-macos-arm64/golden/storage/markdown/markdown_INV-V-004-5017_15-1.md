## Page 1

Orchard Commercial Laundry Pte Ltd
TAX INVOICE INV-V-004-5017
Date: 2026-10-06
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2026-1013
Terms: 30 days from invoice
Item Qty Unit price Amount
Industrial washer extractor Primus WE-966 x1 SGD 32,641.00 SGD 32,641.00
Total: SGD 32,641.00
Serial numbers: SN1579488
