# Technical specification: LED display 75 inch

Equipment: LED display 75 inch LG QD-418.

Purchased from Sentosa Display Technologies Pte Ltd under PO-2023-1078. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | LG |
| --- | --- |
| Model | QD-418 |
| Quantity | 1 |
| Contract value | SGD 3,864 |
