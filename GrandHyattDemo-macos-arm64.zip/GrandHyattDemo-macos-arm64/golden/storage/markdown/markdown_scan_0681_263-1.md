## Data sheet

| Parameter | Value |
| --- | --- |
| Model | PTZ-60 |
| Capacity | 70 racks per hour |
| Dimensions | 700 x 780 x 1980 mm (W x D x H) |
| Weight | 215 kg |
| Electrical load | 18.5 kW connected |
| Voltage | 400 V, 3-phase, 50 Hz |
| Utilities | Cold water 3/4 inch at 2 bar minimum; optional hot inlet at 60 C; drain 40 mm; detergent and rinse aid dosing points |
| Noise | 62 dB(A) |
| Warranty | 12 months from commissioning |
