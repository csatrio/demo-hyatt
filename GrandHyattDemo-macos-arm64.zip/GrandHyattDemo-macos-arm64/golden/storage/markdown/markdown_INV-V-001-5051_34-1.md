## Page 1

Lion City Kitchen Solutions Pte Ltd
TAX INVOICE INV-V-001-5051
Date: 2026-11-07
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2026-1039
Terms: Net 30
Item Qty Unit price Amount
Combi oven Hobart CM-269S x2 SGD 20,179.00 SGD 40,358.00
Total: SGD 40,358.00
Serial numbers: SN2625596, SN2665673
