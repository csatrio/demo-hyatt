## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Ballroom sound system |
| Brand | Bose |
| Model | SS-497X |
| Serial | SN27315255 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
