## Page 1

Kampong Contract Furniture Pte Ltd
TAX INVOICE INV-V-010-5255
Date: 2023-07-22
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2023-1195
Terms: 45 days from invoice
Item Qty Unit price Amount
Lobby sofa Herman Miller LS-708S x1 SGD 6,092.00 SGD 6,092.00
Total: SGD 6,092.00
Serial numbers: SN8588945
