# Technical specification SPEC-26-0013 - Ballroom sound system

Equipment: Ballroom sound system, model SSX-16Z

Supplier: Lion City Kitchen Solutions Pte Ltd (Bose)

Site: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211

Date: 2026-05-11 | Document: SPEC-26-0013

1\. Scope

Feeds 28 ceiling loudspeakers with zone control and a stage paging input. This specification sets out the minimum technical requirements for supply, delivery, installation, testing and commissioning under the hotel refurbishment programme.

2\. Technical data

| Parameter | Requirement |

| Model | SSX-16Z |

| Capacity | 16 loudspeaker zones, 8,000 W total amplifier output |

| Dimensions | 600 x 600 x 1200 mm (rack cabinet) |

| Weight | 185 kg |

| Electrical load | 6.4 kW connected |

| Voltage | 230 V, single phase, 50 Hz |

| Utilities | Dedicated 32 A circuit with isolated earth; Cat 6A to the signal processor; no water |

| Noise | Not applicable |

| Warranty | 24 months from commissioning |

3\. Compliance

\- Electrical installation by a licensed electrical worker to the applicable Singapore wiring standard

\- Electromagnetic compatibility declaration per applicable standard

\- Manufacturer declaration of conformity supplied with the equipment file

4\. Acceptance tests

1\. Frequency response sweep per zone

2\. Zone level calibration to the target sound pressure level

3\. Paging priority override test

4\. Fire alarm mute and override test

Test results are to be recorded on the commissioning form and countersigned by the hotel engineering manager before handover.
