## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Pass-through dishwasher |
| Brand | Foster |
| Model | PT-715A |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 280 |
| Warranty (months) | 24 |
| Manufacturer | Foster |
