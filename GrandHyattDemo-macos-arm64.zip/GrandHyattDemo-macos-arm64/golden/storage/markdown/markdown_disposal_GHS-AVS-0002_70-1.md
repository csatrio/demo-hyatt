## Page 1

Sentosa Display Technologies Pte Ltd
Asset disposal record DSP-26-0002 - LED display 75 inch
Asset disposal record DSP-26-0002
Hotel: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211
Asset tag: GHS-AV-2018-QD-112 | Record date: 2026-03-24
This record covers the disposal of one led display 75 inch from the hotel fixed asset register. The asset has
been inspected and the book value has been confirmed against the register.
Asset details
| Field | Entry |
| Asset category | av |
| Quantity | 1 |
| Reason for disposal | Panel failure; repair uneconomic |
| Condition | Not operable; burn-in on lower left quadrant |
| Book value (SGD) | 1850.00 |
| Disposal method | sale |
| Recipient or buyer | Licensed e-waste recycler, invoiced per unit |
| Net proceeds (SGD) | 320.00 |
Approvals
- AV Manager: approved (2026-05-22)
- Financial Controller: approved (2026-05-25)
The asset is removed from the register only after all approvals are recorded and the disposal certificate or
receipt is filed with this record.
