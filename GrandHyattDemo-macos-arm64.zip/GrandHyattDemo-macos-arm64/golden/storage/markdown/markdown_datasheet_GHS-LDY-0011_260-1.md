## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Tumble dryer |
| Brand | Primus |
| Model | TD-849S |
| Serial | SN17065547 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
