## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Industrial washer extractor |
| Brand | Primus |
| Model | WE-966 |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 26 |
| Weight (kg) | 180 |
| Warranty (months) | 24 |
| Manufacturer | Primus |
