## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Lobby sofa |
| Brand | Steelcase |
| Model | LS-557 |
| Serial | SN32546093 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
