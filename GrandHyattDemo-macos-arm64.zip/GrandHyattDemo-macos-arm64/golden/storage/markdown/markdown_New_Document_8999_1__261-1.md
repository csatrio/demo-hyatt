## Page 1

Clarke Quay Lighting Pte Ltd
Quotation QT-26-0001 - kitchen equipment
Quotation QT-26-0001
From: Clarke Quay Lighting Pte Ltd, 8 Tuas Avenue 20, Singapore 124706
To: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, attention Marcus Lim, Purchasing Manager
Date: 2026-04-23 | Valid until: 2026-05-23
We are pleased to submit our quotation for the supply, delivery, installation and commissioning of the
equipment listed below for the hotel refurbishment programme.
Items
| # | Description | Qty | Unit price (SGD) | Amount (SGD) |
| 1 | Induction range model IR-53 - supply and install | 2 | 7,456.00 | 14,912.00 |
| 2 | Combi oven model CM-52 | 4 | 29,160.00 | 116,640.00 |
Subtotal: SGD 131,552.00
GST (9%): SGD 11,839.68
Total: SGD 143,391.68
Commercial terms
- Payment: 30 days from invoice date by bank transfer
- Delivery: within 6 to 8 weeks after order confirmation
- Warranty: 12 months from commissioning
- Installation works will be carried out outside guest-facing operating hours, subject to the hotel engineering
schedule.
Please quote QT-26-0001 on your purchase order. We look forward to working with the Grand Hyatt Singapore
team.
