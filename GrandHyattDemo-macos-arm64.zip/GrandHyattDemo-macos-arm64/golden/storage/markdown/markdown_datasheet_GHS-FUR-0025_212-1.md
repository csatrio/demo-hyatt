## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Restaurant dining table |
| Brand | Boss Design |
| Model | DT-383A |
| Serial | SN33624549 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
