## Page 1

Lion City Kitchen Solutions Pte Ltd
TAX INVOICE INV-V-001-5085
Date: 2025-08-04
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2025-1065
Terms: 50% deposit, balance on delivery
Item Qty Unit price Amount
Pass-through dishwasher Foster PT-715A x2 SGD 16,794.00 SGD 33,588.00
Total: SGD 33,588.00
Serial numbers: SN3371763, SN3531143
