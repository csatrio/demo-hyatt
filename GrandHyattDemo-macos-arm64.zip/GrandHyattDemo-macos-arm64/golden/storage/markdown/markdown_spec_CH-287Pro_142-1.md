# Technical specification: Chiller unit

Equipment: Chiller unit Daikin CH-287Pro.

Purchased from CoolWave Engineering Pte Ltd under PO-2025-1169. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Daikin |
| --- | --- |
| Model | CH-287Pro |
| Quantity | 1 |
| Contract value | SGD 389,557 |
