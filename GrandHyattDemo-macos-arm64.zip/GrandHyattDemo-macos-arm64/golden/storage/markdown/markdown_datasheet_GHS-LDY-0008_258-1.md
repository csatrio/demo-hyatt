## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Tumble dryer |
| Brand | Primus |
| Model | TD-551B |
| Serial | SN16109138 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
