## Page 1

Raffles M&E Services Pte Ltd
PERMIT TO WORK PTW-2023-388
Work: Install and commission Air handling unit Daikin AHU-226X
Location: Hotel plant and service areas (class 442)
Valid: 2023-05-14 to 2023-05-28
Contractor: Raffles M&E Services Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
