## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Air handling unit |
| Brand | Daikin |
| Model | AHU-226X |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 280 |
| Warranty (months) | 24 |
| Manufacturer | Daikin |
