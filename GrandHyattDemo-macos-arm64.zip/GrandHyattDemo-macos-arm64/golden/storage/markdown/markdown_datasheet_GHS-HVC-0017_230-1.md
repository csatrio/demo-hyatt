## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Air handling unit |
| Brand | Daikin |
| Model | AHU-787X |
| Serial | SN19211905 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
