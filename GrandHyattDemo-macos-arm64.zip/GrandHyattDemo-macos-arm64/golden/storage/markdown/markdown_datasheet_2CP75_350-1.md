## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Circulation pump set |
| Brand | Carrier |
| Model | CP-75 |
| Serial | SN-CAR-871260 |
| Supply | 400 V, 3 phase, 50 Hz |
| Warranty (months) | 24 |
