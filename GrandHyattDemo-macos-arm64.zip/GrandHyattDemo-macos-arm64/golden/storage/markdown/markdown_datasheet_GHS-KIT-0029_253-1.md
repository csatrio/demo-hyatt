## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Ice machine |
| Brand | Hobart |
| Model | IM-570Pro |
| Serial | SN13864200 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
