## Page 1

Bukit Interiors Pte Ltd
TAX INVOICE INV-V-011-5068
Date: 2024-08-14
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2024-1052
Terms: 30 days from invoice
Item Qty Unit price Amount
Lobby sofa Herman Miller LS-277S x2 SGD 7,768.00 SGD 15,536.00
Total: SGD 15,536.00
Serial numbers: SN2713175, SN2803839
