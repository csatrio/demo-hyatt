## Page 1

Straits Laundry Systems Pte Ltd
Asset disposal record DSP-26-0003 - Industrial washer
extractor
Asset disposal record DSP-26-0003
Hotel: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211
Asset tag: GHS-LD-2016-WE-03 | Record date: 2026-04-04
This record covers the disposal of one industrial washer extractor from the hotel fixed asset register. The asset
has been inspected and the book value has been confirmed against the register.
Asset details
| Field | Entry |
| Asset category | laundry |
| Quantity | 1 |
| Reason for disposal | Drum bearing failure; repair cost above 60 percent of replacement cost |
| Condition | Not operable |
| Book value (SGD) | 4200.00 |
| Disposal method | scrap |
| Recipient or buyer | Licensed metal scrap contractor |
| Net proceeds (SGD) | 0.00 |
Approvals
- Director of Engineering: approved (2026-09-03)
- Financial Controller: approved (2026-09-05)
The asset is removed from the register only after all approvals are recorded and the disposal certificate or
receipt is filed with this record.
