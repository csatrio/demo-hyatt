## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Ergonomic office chair |
| Brand | Herman Miller |
| Model | EC-470A |
| Serial | SN38802395 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
