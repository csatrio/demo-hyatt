## Page 1

Sentosa Display Technologies Pte Ltd
TAX INVOICE INV-V-009-5102
Date: 2023-10-24
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2023-1078
Terms: 50% deposit, balance on delivery
Item Qty Unit price Amount
LED display 75 inch LG QD-418 x1 SGD 3,864.00 SGD 3,864.00
Total: SGD 3,864.00
Serial numbers: SN3835374
