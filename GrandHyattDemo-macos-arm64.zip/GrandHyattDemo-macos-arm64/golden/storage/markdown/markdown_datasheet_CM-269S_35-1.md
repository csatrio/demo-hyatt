## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Combi oven |
| Brand | Hobart |
| Model | CM-269S |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 26 |
| Weight (kg) | 380 |
| Warranty (months) | 24 |
| Manufacturer | Hobart |
