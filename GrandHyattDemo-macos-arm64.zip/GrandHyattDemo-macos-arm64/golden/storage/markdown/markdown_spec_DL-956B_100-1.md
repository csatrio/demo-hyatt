# Technical specification: LED downlight array

Equipment: LED downlight array Grohe DL-956B.

Purchased from Clarke Quay Lighting Pte Ltd under PO-2026-1117. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Grohe |
| --- | --- |
| Model | DL-956B |
| Quantity | 3 |
| Contract value | SGD 10,890 |
