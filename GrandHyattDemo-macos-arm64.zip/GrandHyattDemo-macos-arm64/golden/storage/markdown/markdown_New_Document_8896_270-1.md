## Page 1

Orchard Commercial Laundry Pte Ltd
Quotation QT-26-0010 - furniture equipment
Quotation QT-26-0010
From: Orchard Commercial Laundry Pte Ltd, 53 Pioneer Road North, Singapore 341407
To: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, attention Marcus Lim, Purchasing Manager
Date: 2026-01-11 | Valid until: 2026-02-10
We are pleased to submit our quotation for the supply, delivery, installation and commissioning of the
equipment listed below for the hotel refurbishment programme.
Items
| # | Description | Qty | Unit price (SGD) | Amount (SGD) |
| 1 | Ergonomic office chair model EC-38 - supply and deliver | 2 | 705.00 | 1,410.00 |
| 2 | Restaurant dining table model DT-85 - supply and deliver | 3 | 1,641.00 | 4,923.00 |
| 3 | Banquet chair model BQ-67 - supply and install | 26 | 194.00 | 5,044.00 |
Subtotal: SGD 11,377.00
GST (9%): SGD 1,023.93
Total: SGD 12,400.93
Commercial terms
- Payment: 30 days from invoice date by bank transfer
- Delivery: 4 weeks for supply and 1 week for site installation
- Warranty: 18 months from commissioning
- Installation works will be carried out outside guest-facing operating hours, subject to the hotel engineering
schedule.
Please quote QT-26-0010 on your purchase order. We look forward to working with the Grand Hyatt Singapore
team.
