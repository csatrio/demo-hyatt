## Page 1

Telok Ayer Bath and Fittings Pte Ltd
TAX INVOICE INV-V-014-5000
Date: 2025-01-15
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2024-1000
Terms: 30 days from invoice
Item Qty Unit price Amount
LED downlight array Hansgrohe DL-125X x1 SGD 3,042.00 SGD 3,042.00
Total: SGD 3,042.00
Serial numbers: SN1081805
