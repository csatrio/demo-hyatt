# Technical specification: Circulation pump set

Equipment: Carrier CP-75, quantity 2.

Supplied by Tropic Air Systems Pte Ltd. The unit shall comply with Singapore Standards.

| Brand | Carrier |
| --- | --- |
| Model | CP-75 |
| Quantity | 2 |
| Contract value | SGD 13,600.00 |
