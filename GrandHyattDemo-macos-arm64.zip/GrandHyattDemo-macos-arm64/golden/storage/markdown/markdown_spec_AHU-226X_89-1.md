# Technical specification: Air handling unit

Equipment: Air handling unit Daikin AHU-226X.

Purchased from Raffles M&E Services Pte Ltd under PO-2023-1104. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Daikin |
| --- | --- |
| Model | AHU-226X |
| Quantity | 2 |
| Contract value | SGD 81,292 |
