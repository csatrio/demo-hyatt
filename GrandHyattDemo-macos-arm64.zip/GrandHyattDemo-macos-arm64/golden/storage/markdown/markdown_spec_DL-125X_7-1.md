# Technical specification: LED downlight array

Equipment: LED downlight array Hansgrohe DL-125X.

Purchased from Telok Ayer Bath and Fittings Pte Ltd under PO-2024-1000. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Hansgrohe |
| --- | --- |
| Model | DL-125X |
| Quantity | 1 |
| Contract value | SGD 3,042 |
