## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Fan coil unit |
| Brand | Trane |
| Model | FCU-431S |
| Serial | SN21116887 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
