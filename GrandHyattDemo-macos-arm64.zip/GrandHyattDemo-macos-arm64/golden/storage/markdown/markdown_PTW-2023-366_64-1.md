## Page 1

Sentosa Display Technologies Pte Ltd
PERMIT TO WORK PTW-2023-366
Work: Install and commission LED display 75 inch LG QD-418
Location: Hotel plant and service areas (class 421)
Valid: 2023-09-28 to 2023-10-12
Contractor: Sentosa Display Technologies Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
