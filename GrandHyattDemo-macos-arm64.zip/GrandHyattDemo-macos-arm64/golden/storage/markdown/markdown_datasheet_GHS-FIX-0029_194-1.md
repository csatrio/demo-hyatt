## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Rain shower set |
| Brand | Grohe |
| Model | RS-966Pro |
| Serial | SN43303643 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
