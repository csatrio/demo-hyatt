## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED display 75 inch |
| Brand | LG |
| Model | QD-418 |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 80 |
| Warranty (months) | 24 |
| Manufacturer | LG |
