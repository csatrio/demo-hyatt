## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Chiller unit |
| Brand | York |
| Model | CH-346A |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 280 |
| Warranty (months) | 24 |
| Manufacturer | York |
