## Page 1

Telok Ayer Bath and Fittings Pte Ltd
QUOTATION Q-V-014-2200
Date: 2024-11-16
To: Grand Hyatt Singapore Demo - Purchasing
Subject: Supply and install LED downlight array
Payment terms: 30 days from invoice
Validity: 60 days
Delivery: 6-8 weeks from order
Item Qty Unit price Amount
LED downlight array Hansgrohe DL-125X x1 SGD 3,042.00 SGD 3,042.00
Total: SGD 3,042.00
Prices exclude GST. Installation, testing and commissioning included. Warranty 24 months.
