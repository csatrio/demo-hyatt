## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Laser projector |
| Brand | LG |
| Model | EB-135Pro |
| Serial | SN26637396 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
