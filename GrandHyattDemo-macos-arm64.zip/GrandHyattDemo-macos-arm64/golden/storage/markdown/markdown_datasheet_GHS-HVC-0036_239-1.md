## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Split air conditioner |
| Brand | Trane |
| Model | SAC-789B |
| Serial | SN22557908 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
