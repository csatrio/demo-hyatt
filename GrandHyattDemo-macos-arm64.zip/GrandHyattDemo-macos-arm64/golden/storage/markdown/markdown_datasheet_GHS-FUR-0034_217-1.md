## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Guest room bed set |
| Brand | Vitra |
| Model | BD-614 |
| Serial | SN35286975 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
