## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Pass-through dishwasher |
| Brand | Winterhalter |
| Model | PT-185S |
| Serial | SN12225151 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
