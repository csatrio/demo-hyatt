## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Banquet chair |
| Brand | Vitra |
| Model | BQ-179B |
| Serial | SN31449728 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
