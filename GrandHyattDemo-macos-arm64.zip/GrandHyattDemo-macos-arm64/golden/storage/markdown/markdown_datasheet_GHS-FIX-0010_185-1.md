## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Crystal chandelier |
| Brand | Kohler |
| Model | CD-308B |
| Serial | SN39089235 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
