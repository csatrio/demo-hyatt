## Page 1

Lion City Kitchen Solutions Pte Ltd
PERMIT TO WORK PTW-2026-333
Work: Install and commission Combi oven Hobart CM-269S
Location: Hotel plant and service areas (class 431)
Valid: 2026-10-12 to 2026-10-26
Contractor: Lion City Kitchen Solutions Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
