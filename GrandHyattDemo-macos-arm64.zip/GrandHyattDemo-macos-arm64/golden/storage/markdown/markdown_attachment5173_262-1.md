## Page 1

Kampong Contract Furniture Pte Ltd
Invoice INV-26-0002 - furniture supply
Tax Invoice INV-26-0002
From: Kampong Contract Furniture Pte Ltd, 53 Pioneer Road North, Singapore 341407
Bill to: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, Accounts Payable
Invoice date: 2026-05-18 | Due date: 2026-06-17
Reference PO: PO-26-0003
This invoice relates to a partial delivery against purchase order PO-26-0003. Goods were received and
checked by the hotel receiving team.
Items
| # | Description | Qty | Unit price (SGD) | Amount (SGD) |
| 1 | Restaurant dining table model DT-41 - supply, install and commission | 1 | 1,388.00 | 1,388.00 |
Subtotal: SGD 1,388.00
GST (9%): SGD 124.92
Total due: SGD 1,512.92
Payment
- Payment due by 2026-06-17, quoting INV-26-0002.
- Remittance advice should be sent to the accounts team in Finance, quoting the invoice number and the PO
reference shown above.
Notes
Quantities and serial numbers were checked against the delivery note and signed by the receiving supervisor
on arrival at the loading bay, with any shortages recorded on the goods received note before this invoice was
raised.
- Please notify us within 7 days of any discrepancy in quantities.
