## Page 1

CoolWave Engineering Pte Ltd
TAX INVOICE INV-V-005-5170
Date: 2023-05-17
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2023-1130
Terms: 50% deposit, balance on delivery
Item Qty Unit price Amount
Chiller unit Daikin CH-921B x1 SGD 315,683.00 SGD 315,683.00
Total: SGD 315,683.00
Serial numbers: SN6013206
