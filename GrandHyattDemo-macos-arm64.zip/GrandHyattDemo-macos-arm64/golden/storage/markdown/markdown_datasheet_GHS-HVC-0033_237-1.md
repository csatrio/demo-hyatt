## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Fan coil unit |
| Brand | Carrier |
| Model | FCU-761S |
| Serial | SN21799487 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
