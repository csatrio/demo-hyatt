## Page 1

RECEIPT
Item: Taxi fare for a vendor visit
Paid: S$ 38.50 on 2026-10-06
Shop: Demo hardware and stationery
Generated demo receipt.
