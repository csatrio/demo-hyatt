## Page 1

Grand Hyatt Singapore Demo - Engineering
ASSET DISPOSAL FORM GHS-KIT-0033
Asset: Ice machine IM-293B
Serial: SN14581635
Reason: Replaced by Combi oven 20 tray (SCC-202G)
Date: 2026-11-15
Method: Sold to licensed recycler
