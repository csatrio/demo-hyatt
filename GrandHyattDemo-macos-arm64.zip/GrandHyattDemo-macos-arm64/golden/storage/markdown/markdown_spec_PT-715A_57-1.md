# Technical specification: Pass-through dishwasher

Equipment: Pass-through dishwasher Foster PT-715A.

Purchased from Lion City Kitchen Solutions Pte Ltd under PO-2025-1065. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Foster |
| --- | --- |
| Model | PT-715A |
| Quantity | 2 |
| Contract value | SGD 33,588 |
