# Technical specification: Crystal chandelier

Equipment: Crystal chandelier Grohe CD-188Pro.

Purchased from Clarke Quay Lighting Pte Ltd under PO-2024-1026. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Grohe |
| --- | --- |
| Model | CD-188Pro |
| Quantity | 3 |
| Contract value | SGD 75,204 |
