## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Executive desk |
| Brand | King Koil |
| Model | XD-848S |
| Serial | SN37435388 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
