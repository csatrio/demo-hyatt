## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED downlight array |
| Brand | Signify |
| Model | DL-919B |
| Serial | SN40358611 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
