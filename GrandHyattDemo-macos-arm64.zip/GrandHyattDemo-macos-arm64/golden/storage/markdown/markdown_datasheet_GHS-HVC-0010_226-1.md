## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Chiller unit |
| Brand | Trane |
| Model | CH-221A |
| Serial | SN17776734 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
