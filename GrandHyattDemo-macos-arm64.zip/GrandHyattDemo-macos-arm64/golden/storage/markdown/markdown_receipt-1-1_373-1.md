## Page 1

RECEIPT
Item: Cleaning cloths and gloves
Paid: S$ 48.50 on 2026-10-02
Shop: Demo hardware and stationery
Generated demo receipt.
