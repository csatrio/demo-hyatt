# Operation and maintenance manual: Circulation pump set

1\. Safety and isolation before any cleaning or service.

2\. Daily operation: check indicators and drain points.

3\. Planned maintenance by Tropic Air Systems Pte Ltd: quarterly inspection, annual service.

| Daily | Visual check |
| --- | --- |
| Quarterly | Inspection by vendor |
| Annual | Full service |
