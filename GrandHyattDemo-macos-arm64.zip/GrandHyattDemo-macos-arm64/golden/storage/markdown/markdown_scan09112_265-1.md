## Page 1

Clarke Quay Lighting Pte Ltd
Permit to work PTW-26-0005 - Removal of existing lobby sofa
for refurbishment
Permit to Work PTW-26-0005
Contractor: Clarke Quay Lighting Pte Ltd | Supervisor: Ong Boon Kiat
Valid: 2026-04-07 07:00 to 2026-04-07 18:00 | Location: Level 5 meeting rooms
Scope
Removal of existing lobby sofa for refurbishment. Work is limited to the isolated equipment and the access route
shown on the attached sketch.
Isolation
No utility isolation required. Keep the area barricaded and confirm power tools are tested and tagged before
use.
Hazards and controls
- Electrical isolation and lock-out/tag-out (LOTO)
- Manual handling of heavy components
- Slips, trips and falls in service corridors
- Pinch points and sharp edges during handling
Hot work and working at height
- Hot work: No hot work is permitted under this permit.
- Working at height: No, all work is at ground level.
Signatories
| Role | Name | Signed on |
| Requesting Engineer | Benjamin Koh | ____ |
| Contractor Supervisor | Ong Boon Kiat | ____ |
| Chief Engineer (approver) | Raj Kumar | ____ |
| Maintenance witness | Noor Hidayah | ____ |
The permit is void if conditions change. Contractor must stop work and inform the duty engineer immediately.
