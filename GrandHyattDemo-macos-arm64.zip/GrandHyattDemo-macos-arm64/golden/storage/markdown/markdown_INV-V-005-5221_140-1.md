## Page 1

CoolWave Engineering Pte Ltd
TAX INVOICE INV-V-005-5221
Date: 2025-03-15
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2025-1169
Terms: 45 days from invoice
Item Qty Unit price Amount
Chiller unit Daikin CH-287Pro x1 SGD 389,557.00 SGD 389,557.00
Total: SGD 389,557.00
Serial numbers: SN7518553
