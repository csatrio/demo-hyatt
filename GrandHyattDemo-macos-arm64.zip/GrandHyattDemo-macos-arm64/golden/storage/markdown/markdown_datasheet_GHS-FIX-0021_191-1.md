## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Rain shower set |
| Brand | Kohler |
| Model | RS-264Pro |
| Serial | SN41493475 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
