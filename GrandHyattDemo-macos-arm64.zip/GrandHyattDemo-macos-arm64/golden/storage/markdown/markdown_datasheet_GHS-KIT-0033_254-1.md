## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Ice machine |
| Brand | Foster |
| Model | IM-293B |
| Serial | SN14581635 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
