## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Blast chiller |
| Brand | Hobart |
| Model | BC-579X |
| Serial | SN9702950 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
