## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Lobby sofa |
| Brand | Steelcase |
| Model | LS-712A |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 280 |
| Warranty (months) | 24 |
| Manufacturer | Steelcase |
