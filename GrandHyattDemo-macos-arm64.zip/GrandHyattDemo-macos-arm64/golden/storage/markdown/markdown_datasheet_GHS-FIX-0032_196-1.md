## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Vanity basin and mixer |
| Brand | Signify |
| Model | VB-533Pro |
| Serial | SN43744686 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
