# Technical specification: Chiller unit

Equipment: Chiller unit York CH-346A.

Purchased from Raffles M&E Services Pte Ltd under PO-2026-1091. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | York |
| --- | --- |
| Model | CH-346A |
| Quantity | 1 |
| Contract value | SGD 277,994 |
