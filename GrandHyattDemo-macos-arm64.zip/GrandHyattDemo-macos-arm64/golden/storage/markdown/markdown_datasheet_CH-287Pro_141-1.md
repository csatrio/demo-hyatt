## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Chiller unit |
| Brand | Daikin |
| Model | CH-287Pro |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 26 |
| Weight (kg) | 180 |
| Warranty (months) | 24 |
| Manufacturer | Daikin |
