## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Air handling unit |
| Brand | Trane |
| Model | AHU-744A |
| Serial | SN18368164 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
