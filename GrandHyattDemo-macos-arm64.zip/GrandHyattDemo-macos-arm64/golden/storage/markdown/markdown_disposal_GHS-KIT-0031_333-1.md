## Page 1

Grand Hyatt Singapore Demo - Engineering
ASSET DISPOSAL FORM GHS-KIT-0031
Asset: Ice machine IM-633
Serial: SN14094659
Reason: Replaced by Combi steamer 10 tray (XEVC-1011)
Date: 2026-11-15
Method: Sold to licensed recycler
