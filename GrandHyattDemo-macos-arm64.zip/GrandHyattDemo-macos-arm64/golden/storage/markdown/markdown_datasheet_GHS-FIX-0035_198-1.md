## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Vanity basin and mixer |
| Brand | Duravit |
| Model | VB-941X |
| Serial | SN43948174 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
