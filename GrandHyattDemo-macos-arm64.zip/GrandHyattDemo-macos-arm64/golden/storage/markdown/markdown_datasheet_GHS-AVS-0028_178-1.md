## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Guest room television 55 inch |
| Brand | LG |
| Model | GT-644 |
| Serial | SN28706898 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
