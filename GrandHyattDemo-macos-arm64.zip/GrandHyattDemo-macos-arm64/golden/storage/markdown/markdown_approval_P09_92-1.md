## Page 1

CoolWave Engineering Pte Ltd
Singapore Civil Defence Force approval SCDF/FSD/26/0412
Fire safety installation approval - SCDF/FSD/26/0412
Reference: SCDF/FSD/26/0412 | Date: 2026-03-18 | Valid until: 2027-03-17
To: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, attention Director of Engineering
Copy: CoolWave Engineering Pte Ltd, installing contractor
Subject: Approval for installation of air handling unit with fire dampers and smoke control interface
Dear Sir or Madam,
We refer to your submission of 2026-02-24 for the installation of air handling unit model AHX-25 serving the
ballroom supply air system. Based on the drawings and test records submitted, the installation is approved
subject to the conditions below.
Conditions
1. Fire dampers rated for one hour to be tested and certified by a competent person before commissioning.
2. Smoke detector interface to be tested against the fire alarm control panel with results recorded.
3. Duct penetrations through fire-rated walls to be sealed to the rated fire resistance.
4. Inspection and maintenance log to be kept on site and produced on request.
This approval is valid until 2027-03-17. Any change to the layout, capacity or equipment requires a fresh
submission. Please quote the reference number in all correspondence.
Yours faithfully,
Singapore Civil Defence Force, Fire Safety Department
