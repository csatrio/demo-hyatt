## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Split air conditioner |
| Brand | Trane |
| Model | SAC-384B |
| Serial | SN23403343 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
