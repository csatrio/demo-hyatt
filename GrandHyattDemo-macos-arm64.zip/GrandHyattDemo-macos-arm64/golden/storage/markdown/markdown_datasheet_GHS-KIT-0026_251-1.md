## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Induction range |
| Brand | Rational |
| Model | IR-483Pro |
| Serial | SN13088336 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
