## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Walk-in chiller |
| Brand | Winterhalter |
| Model | WC-439S |
| Serial | SN11385344 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
