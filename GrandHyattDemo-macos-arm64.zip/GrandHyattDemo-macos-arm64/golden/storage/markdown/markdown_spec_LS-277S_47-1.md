# Technical specification: Lobby sofa

Equipment: Lobby sofa Herman Miller LS-277S.

Purchased from Bukit Interiors Pte Ltd under PO-2024-1052. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Herman Miller |
| --- | --- |
| Model | LS-277S |
| Quantity | 2 |
| Contract value | SGD 15,536 |
