## Page 1

Raffles M&E Services Pte Ltd
TAX INVOICE INV-V-007-5119
Date: 2026-06-23
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2026-1091
Terms: 30 days from invoice
Item Qty Unit price Amount
Chiller unit York CH-346A x1 SGD 277,994.00 SGD 277,994.00
Total: SGD 277,994.00
Serial numbers: SN4339480
