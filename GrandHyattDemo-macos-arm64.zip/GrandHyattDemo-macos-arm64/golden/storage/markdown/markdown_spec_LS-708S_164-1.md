# Technical specification: Lobby sofa

Equipment: Lobby sofa Herman Miller LS-708S.

Purchased from Kampong Contract Furniture Pte Ltd under PO-2023-1195. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Herman Miller |
| --- | --- |
| Model | LS-708S |
| Quantity | 1 |
| Contract value | SGD 6,092 |
