# Technical specification: Chiller unit

Equipment: Chiller unit Daikin CH-921B.

Purchased from CoolWave Engineering Pte Ltd under PO-2023-1130. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Daikin |
| --- | --- |
| Model | CH-921B |
| Quantity | 1 |
| Contract value | SGD 315,683 |
