## Page 1

Regulatory authority (synthetic)
CERTIFICATE OF APPROVAL
Equipment: Carrier CP-75
Premises: Grand Hyatt Singapore Demo
Reference: AA-2CP75
Date: 2026-12-11
Decision: Approved for use
