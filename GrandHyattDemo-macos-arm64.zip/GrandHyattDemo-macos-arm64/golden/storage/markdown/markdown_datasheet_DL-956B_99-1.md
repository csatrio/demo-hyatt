## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | LED downlight array |
| Brand | Grohe |
| Model | DL-956B |
| Supply | 400 V, 3 phase, 50 Hz |
| Rated power (kW) | 6 |
| Weight (kg) | 280 |
| Warranty (months) | 24 |
| Manufacturer | Grohe |
