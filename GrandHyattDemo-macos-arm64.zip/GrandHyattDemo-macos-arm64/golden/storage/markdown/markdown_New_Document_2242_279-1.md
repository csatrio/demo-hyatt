## Page 1

Telok Ayer Bath and Fittings Pte Ltd
Quotation QT-26-0019 - hvac equipment
Quotation QT-26-0019
From: Telok Ayer Bath and Fittings Pte Ltd, 47 Gul Circle, Singapore 306098
To: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, attention Marcus Lim, Purchasing Manager
Date: 2026-03-07 | Valid until: 2026-04-06
We are pleased to submit our quotation for the supply, delivery, installation and commissioning of the
equipment listed below for the hotel refurbishment programme.
Items
| # | Description | Qty | Unit price (SGD) | Amount (SGD) |
| 1 | Cooling tower model CT-39 - supply and deliver | 3 | 78,806.00 | 236,418.00 |
| 2 | Cooling tower model CT-96 - supply and install | 4 | 93,037.00 | 372,148.00 |
| 3 | Air handling unit model AHU-45 - supply, install and commission | 1 | 89,145.00 | 89,145.00 |
| 4 | Split air conditioner model SAC-30 - supply, install and commission | 1 | 2,967.00 | 2,967.00 |
Subtotal: SGD 700,678.00
GST (9%): SGD 63,061.02
Total: SGD 763,739.02
Commercial terms
- Payment: 45 days from invoice date by GIRO or bank transfer
- Delivery: 4 weeks for supply and 1 week for site installation
- Warranty: 18 months from commissioning
- Prices exclude removal and disposal of existing equipment unless stated otherwise.
Please quote QT-26-0019 on your purchase order. We look forward to working with the Grand Hyatt Singapore
team.
