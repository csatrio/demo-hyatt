## Page 1

Harbourfront Furnishings Pte Ltd
TAX INVOICE INV-V-012-5238
Date: 2026-09-02
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2026-1182
Terms: 30 days from invoice
Item Qty Unit price Amount
Lobby sofa Steelcase LS-712A x3 SGD 5,574.00 SGD 16,722.00
Total: SGD 16,722.00
Serial numbers: SN7884815, SN8211181, SN8463194
