## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Vanity basin and mixer |
| Brand | Grohe |
| Model | VB-959S |
| Serial | SN44897829 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
