## Data sheet

| Parameter | Value |
| --- | --- |
| Model | VPZ-9K |
| Capacity | 12,000 ANSI lumens, laser light source |
| Dimensions | 560 x 460 x 190 mm (W x D x H) |
| Weight | 18 kg |
| Electrical load | 1.4 kW connected |
| Voltage | 230 V, single phase, 50 Hz |
| Utilities | Cat 6A network cable; HDBaseT extension; RS-232 control |
| Noise | 36 dB(A) |
| Warranty | 12 months from commissioning |
