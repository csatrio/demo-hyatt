# Operation and maintenance manual: Crystal chandelier

1\. Safety and isolation. Switch off and lock out before any cleaning or service.

2\. Daily operation. Check indicators and drain points at start of shift.

3\. Planned maintenance. Quarterly inspection by an authorised technician; annual full service.

4\. Contact. Clarke Quay Lighting Pte Ltd, service hotline on the vendor card.

| Daily | Visual check, clean filters |
| --- | --- |
| Quarterly | Inspection by vendor |
| Annual | Full service and safety test |
