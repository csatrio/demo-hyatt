# Technical specification: Pass-through dishwasher

Equipment: Pass-through dishwasher Foster PT-195Pro.

Purchased from Lion City Kitchen Solutions Pte Ltd under PO-2025-1143. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Foster |
| --- | --- |
| Model | PT-195Pro |
| Quantity | 2 |
| Contract value | SGD 30,616 |
