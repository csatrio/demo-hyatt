## Page 1

Kampong Contract Furniture Pte Ltd
Asset disposal record DSP-26-0001 - Banquet chair lot (40
units)
Asset disposal record DSP-26-0001
Hotel: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211
Asset tag: GHS-FFE-2019-BQ-040 | Record date: 2026-02-17
This record covers the disposal of 40 banquet chair lot (40 units) from the hotel fixed asset register. The asset
has been inspected and the book value has been confirmed against the register.
Asset details
| Field | Entry |
| Asset category | furniture |
| Quantity | 40 |
| Reason for disposal | Replaced by new banquet chair lot under the 2026 refurbishment |
| Condition | Fair; 12 units with cracked seat frames |
| Book value (SGD) | 1280.00 |
| Disposal method | donation |
| Recipient or buyer | Registered charity partner, to be confirmed in writing |
| Net proceeds (SGD) | 0.00 |
Approvals
- Director of Engineering: approved (2026-08-12)
- Financial Controller: approved (2026-08-14)
- General Manager: pending
The asset is removed from the register only after all approvals are recorded and the disposal certificate or
receipt is filed with this record.
