## Page 1

Lion City Kitchen Solutions Pte Ltd
PERMIT TO WORK PTW-2025-355
Work: Install and commission Pass-through dishwasher Foster PT-715A
Location: Hotel plant and service areas (class 431)
Valid: 2025-07-09 to 2025-07-23
Contractor: Lion City Kitchen Solutions Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
