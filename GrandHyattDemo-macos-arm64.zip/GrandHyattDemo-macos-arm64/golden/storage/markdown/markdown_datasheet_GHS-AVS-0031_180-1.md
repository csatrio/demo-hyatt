## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Guest room television 55 inch |
| Brand | Samsung |
| Model | GT-297 |
| Serial | SN29087032 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
