## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Guest room bed set |
| Brand | King Koil |
| Model | BD-627A |
| Serial | SN34858116 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
