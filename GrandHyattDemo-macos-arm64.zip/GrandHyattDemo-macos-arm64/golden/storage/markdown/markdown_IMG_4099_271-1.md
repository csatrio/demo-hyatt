## Page 1

Raffles M&E Services Pte Ltd
Invoice INV-26-0011 - hvac supply
Tax Invoice INV-26-0011
From: Raffles M&E Services Pte Ltd, 30 Tampines Street 92, Singapore 593107
Bill to: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, Accounts Payable
Invoice date: 2026-06-16 | Due date: 2026-07-16
Reference PO: PO-26-0002
This invoice relates to the second delivery against purchase order PO-26-0002. Goods were received and
checked by the hotel receiving team.
Items
| # | Description | Qty | Unit price (SGD) | Amount (SGD) |
| 1 | Chiller unit model CH-40 | 1 | 347,640.00 | 347,640.00 |
| 2 | Cooling tower model CT-26 - supply and install | 2 | 106,580.00 | 213,160.00 |
Subtotal: SGD 560,800.00
GST (9%): SGD 50,472.00
Total due: SGD 611,272.00
Payment
- Payment due by 2026-07-16, quoting INV-26-0011.
- Remittance advice should be sent to the accounts team in Finance, quoting the invoice number and the PO
reference shown above.
Notes
Quantities and serial numbers were checked against the delivery note and signed by the receiving supervisor
on arrival at the loading bay, with any shortages recorded on the goods received note before this invoice was
raised.
- Late payment interest is not charged on disputed items.
