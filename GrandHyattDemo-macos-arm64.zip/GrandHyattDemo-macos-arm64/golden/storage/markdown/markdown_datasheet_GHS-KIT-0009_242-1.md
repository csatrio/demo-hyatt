## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Combi oven |
| Brand | Unox |
| Model | CM-172Pro |
| Serial | SN8942831 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 12 |
