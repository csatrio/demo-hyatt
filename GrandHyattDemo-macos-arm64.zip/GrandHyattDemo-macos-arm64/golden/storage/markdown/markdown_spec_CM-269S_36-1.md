# Technical specification: Combi oven

Equipment: Combi oven Hobart CM-269S.

Purchased from Lion City Kitchen Solutions Pte Ltd under PO-2026-1039. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Hobart |
| --- | --- |
| Model | CM-269S |
| Quantity | 2 |
| Contract value | SGD 40,358 |
