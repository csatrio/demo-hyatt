## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Restaurant dining table |
| Brand | Vitra |
| Model | DT-328S |
| Serial | SN34255459 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
