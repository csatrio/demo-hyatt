## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Cooling tower |
| Brand | Trane |
| Model | CT-841Pro |
| Serial | SN19751477 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 36 |
