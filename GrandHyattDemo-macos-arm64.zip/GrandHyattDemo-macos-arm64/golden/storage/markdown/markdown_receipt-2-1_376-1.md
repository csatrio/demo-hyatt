## Page 1

RECEIPT
Item: Courier fee for a sample
Paid: S$ 32.00 on 2026-10-03
Shop: Demo hardware and stationery
Generated demo receipt.
