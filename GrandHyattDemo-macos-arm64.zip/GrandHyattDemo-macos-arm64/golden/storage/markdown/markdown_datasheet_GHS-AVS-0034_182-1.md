## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Guest room television 55 inch |
| Brand | Bose |
| Model | GT-643B |
| Serial | SN29538707 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
