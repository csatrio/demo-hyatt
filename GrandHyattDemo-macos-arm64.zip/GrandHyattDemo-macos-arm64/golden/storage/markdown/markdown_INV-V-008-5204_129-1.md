## Page 1

Merlion AV Integrators Pte Ltd
TAX INVOICE INV-V-008-5204
Date: 2026-01-24
Customer: Grand Hyatt Singapore Demo
Your PO: PO-2025-1156
Terms: Net 30
Item Qty Unit price Amount
LED display 75 inch Epson QD-550Pro x3 SGD 4,661.00 SGD 13,983.00
Total: SGD 13,983.00
Serial numbers: SN7007932, SN7099618, SN7293406
