## Page 1

Raffles M&E Services Pte Ltd
National Environment Agency approval NEA/OZ/26/1138
Refrigerant equipment installation notice - NEA/OZ/26/1138
Reference: NEA/OZ/26/1138 | Date: 2026-06-02 | Valid until: 2027-06-01
To: Grand Hyatt Singapore, 10 Scotts Road, Singapore 228211, attention Director of Engineering
Copy: Raffles M&E Services Pte Ltd, installing contractor
Subject: Notice of acceptance for installation of a refrigerant-containing chiller unit at the rooftop plant room
Dear Sir or Madam,
Thank you for notifying the agency of the planned installation of a water-cooled chiller unit containing refrigerant
at the hotel rooftop plant room. The notice has been accepted on the basis of the details provided, and the
conditions below apply throughout the life of the equipment.
Conditions
1. Refrigerant type and charge to be recorded in the equipment register and kept on site.
2. Leak detection and an annual leak check to be carried out by a licensed contractor.
3. Refrigerant to be recovered by a licensed contractor at decommissioning.
4. Any release above the reporting threshold to be notified to the agency within 30 days.
This approval is valid until 2027-06-01. Any change to the layout, capacity or equipment requires a fresh
submission. Please quote the reference number in all correspondence.
Yours faithfully,
National Environment Agency, Environmental Management Division
