## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Lobby sofa |
| Brand | Herman Miller |
| Model | LS-123S |
| Serial | SN31906420 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 24 |
