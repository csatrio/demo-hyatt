## Data sheet

| Parameter | Value |
| --- | --- |
| Equipment | Ergonomic office chair |
| Brand | King Koil |
| Model | EC-938X |
| Serial | SN38141824 |
| Supply | 230 V, 50 Hz |
| Warranty (months) | 48 |
