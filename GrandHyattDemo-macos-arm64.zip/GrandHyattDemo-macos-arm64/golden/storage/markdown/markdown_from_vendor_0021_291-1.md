## Page 1

LAUNDRY CHEMICAL HANDLING AND SAFETY SHEET
Line 1: Sheet 52-3190
Line 2: Supplier Diversey Singapore
Line 3: Laundry detergent concentrate: hazard statements, first aid measures, PPE, spill handling
and storage
Line 4: Keep away from acids; rinse eyes for 15 minutes
