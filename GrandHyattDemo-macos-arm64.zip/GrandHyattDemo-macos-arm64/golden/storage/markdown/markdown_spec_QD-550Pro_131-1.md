# Technical specification: LED display 75 inch

Equipment: LED display 75 inch Epson QD-550Pro.

Purchased from Merlion AV Integrators Pte Ltd under PO-2025-1156. The unit shall comply with Singapore Standards and the hotel's engineering standards.

Installation by the vendor under a permit to work; testing and commissioning witnessed by hotel engineering.

| Brand | Epson |
| --- | --- |
| Model | QD-550Pro |
| Quantity | 3 |
| Contract value | SGD 13,983 |
