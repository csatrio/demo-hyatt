## Page 1

Telok Ayer Bath and Fittings Pte Ltd
PERMIT TO WORK PTW-2024-300
Work: Install and commission LED downlight array Hansgrohe DL-125X
Location: Hotel plant and service areas (class 423)
Valid: 2024-12-20 to 2025-01-03
Contractor: Telok Ayer Bath and Fittings Pte Ltd
Issued by: Raj Kumar (Chief Engineer)
Hot work: no. Isolation: lock-out/tag-out by hotel engineering. Fire watch required during cutting. Barricade and
signage at the work area.
